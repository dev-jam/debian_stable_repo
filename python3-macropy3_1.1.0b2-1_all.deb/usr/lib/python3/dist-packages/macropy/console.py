"""Shorthand import to initialize the MacroPy console"""
import macropy.activate
macropy.console()