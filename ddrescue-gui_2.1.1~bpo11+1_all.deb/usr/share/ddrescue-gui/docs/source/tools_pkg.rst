Documentation for the tools package (Tools)
*******************************************

.. automodule:: ddrescue_gui.Tools
    :members:
