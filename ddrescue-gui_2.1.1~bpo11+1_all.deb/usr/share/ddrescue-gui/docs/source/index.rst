.. DDRescue-GUI documentation master file, created by
   sphinx-quickstart on Thu Jun  7 14:41:47 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to DDRescue-GUI's Developer documentation!
==================================================

Contents:

.. toctree::
    :maxdepth: 2

    main_file
    py2app_setup_file
    unit_tests_file
    unit_tests_pkg
    tools_pkg
    tools_coretools
    tools_mounttools
    tools_ddrescuetools
    tools_ddrescuetools_setup
    tools_ddrescuetools_decorators
    tools_ddrescuetools_allversions
    tools_ddrescuetools_114
    tools_ddrescuetools_118
    tools_ddrescuetools_120
    tools_ddrescuetools_121
    tools_ddrescuetools_122

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

