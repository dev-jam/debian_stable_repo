Documentation for the ddrescue tools package in the tools package (Tools/DDRescueTools)
***************************************************************************************

.. automodule:: ddrescue_gui.Tools.DDRescueTools
    :members:
