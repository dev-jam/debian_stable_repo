Documentation for the ddrescue tools for ddrescue version 1.22 in the ddrescue tools package in the tools package (Tools/DDRescueTools/one_point_twenty_two.py)
***************************************************************************************************************************************************************

.. automodule:: ddrescue_gui.Tools.DDRescueTools.one_point_twenty_two
    :members:
