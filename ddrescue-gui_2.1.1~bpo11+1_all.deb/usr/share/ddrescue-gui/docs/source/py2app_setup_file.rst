Documentation for the py2app setup file (setup.py)
**************************************************

.. automodule:: ddrescue_gui.setup
    :members:
