Documentation for the allversions module in the ddrescue tools package in the tools package (Tools/DDRescueTools/allversions.py)
********************************************************************************************************************************

.. automodule:: ddrescue_gui.Tools.DDRescueTools.allversions
    :members:
