:orphan:

.. meta::

  :http-equiv=refresh: 3; url=../../cli/pip/

This page has moved
===================

You should be redirected automatically in 3 seconds. If that didn't
work, here's a link: :doc:`../cli/pip`
