Documentation for the dictionary setup module in the tools package
******************************************************************

.. automodule:: wxfixboot.Tools.dictionaries
    :members:
