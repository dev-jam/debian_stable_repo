Documentation for the notebook tools in the tools package
*********************************************************

.. automodule:: wxfixboot.Tools.notebookfunctions
    :members:
