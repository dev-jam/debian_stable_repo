Documentation for the unit tests executable (tests.py)
******************************************************

.. automodule:: wxfixboot.tests
    :members:
