Documentation for the dialog tools in the tools package
*******************************************************

.. automodule:: wxfixboot.Tools.dialogtools
    :members:
