Documentation for the main executable file (WxFixBoot.py)
************************************************************

.. automodule:: wxfixboot.WxFixBoot
    :members:
