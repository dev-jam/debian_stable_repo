Documentation for the unit tests package
****************************************

.. automodule:: wxfixboot.Tests
    :members:
